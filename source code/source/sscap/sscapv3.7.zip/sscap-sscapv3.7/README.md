SSCap is a shadosocks client written in C++, MFC<br/>
<br/>
Features<br/>
1, System proxy configration<br/>
2, PAC mode and global mode<br/>
3, Support UDP relay<br/>
4, Support HTTP proxy<br/>
5, Support proxy node real-time testing via TCP & UDP<br/>
6, Compatible from XP to WIN10 system<br/>

Develop<br/>
VS.net 2010<br/>
<br/>
作者没有时间来维护此项目，希望有兴趣的网友能继续维护添加新功能。<br/>

