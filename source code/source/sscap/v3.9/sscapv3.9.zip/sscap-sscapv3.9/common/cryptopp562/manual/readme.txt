menual
http://www.cryptopp.com/docs/ref/index.html

wiki
http://www.cryptopp.com/wiki/Main_Page