#pragma once
#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions

//#include <windows.h>
#include <winsock2.h>
#include <tchar.h>